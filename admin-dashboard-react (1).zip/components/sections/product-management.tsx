"use client"

import { useState } from "react"
import { Plus, Search, Edit2, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import ProductForm from "../product-form"
import { useTheme } from "../admin-dashboard"

interface Product {
  id: number
  name: string
  sku: string
  price: string
  stock: number
  category: string
  status: string
}

interface ProductManagementProps {
  products?: Product[]
  onAddProduct?: (product: any) => void
  onEditProduct?: (id: number) => void
  onDeleteProduct?: (id: number) => void
}

const colorMap = {
  green: { bg: "bg-green-600", hover: "hover:bg-green-700" },
  blue: { bg: "bg-blue-600", hover: "hover:bg-blue-700" },
  red: { bg: "bg-red-600", hover: "hover:bg-red-700" },
  orange: { bg: "bg-orange-600", hover: "hover:bg-orange-700" },
}

export default function ProductManagement({
  products = [],
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
}: ProductManagementProps) {
  const [showForm, setShowForm] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const { isDarkMode, accentColor, t } = useTheme()
  const colors = colorMap[accentColor as keyof typeof colorMap] || colorMap.green

  const filteredProducts = products.filter((product) => product.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`text-3xl font-bold ${isDarkMode ? "text-white" : "text-gray-900"}`}>
            {t("productManagement")}
          </h1>
          <p className={isDarkMode ? "text-gray-400" : "text-gray-600"}>Add, edit, and manage your product inventory</p>
        </div>
        <Button onClick={() => setShowForm(true)} className={`${colors.bg} ${colors.hover} text-white gap-2`}>
          <Plus size={18} />
          {t("addNewProduct")}
        </Button>
      </div>

      {showForm && <ProductForm onClose={() => setShowForm(false)} onSubmit={onAddProduct} />}

      {/* Search and Filter */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search size={18} className="absolute left-3 top-3 text-gray-400" />
          <Input
            placeholder={t("searchProducts")}
            className={`pl-10 ${isDarkMode ? "bg-gray-800 border-gray-700 text-white" : ""}`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Products Table */}
      <div
        className={`bg-white rounded-lg border border-gray-200 overflow-hidden ${isDarkMode ? "bg-gray-800 border-gray-700" : ""}`}
      >
        <table className="w-full">
          <thead className={`bg-gray-50 border-b border-gray-200 ${isDarkMode ? "bg-gray-900 border-gray-700" : ""}`}>
            <tr>
              <th
                className={`px-6 py-3 text-left text-sm font-semibold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}
              >
                {t("name")}
              </th>
              <th
                className={`px-6 py-3 text-left text-sm font-semibold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}
              >
                {t("sku")}
              </th>
              <th
                className={`px-6 py-3 text-left text-sm font-semibold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}
              >
                {t("price")}
              </th>
              <th
                className={`px-6 py-3 text-left text-sm font-semibold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}
              >
                {t("stock")}
              </th>
              <th
                className={`px-6 py-3 text-left text-sm font-semibold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}
              >
                {t("category")}
              </th>
              <th
                className={`px-6 py-3 text-left text-sm font-semibold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}
              >
                {t("status")}
              </th>
              <th
                className={`px-6 py-3 text-center text-sm font-semibold ${isDarkMode ? "text-gray-300" : "text-gray-700"}`}
              >
                {t("actions")}
              </th>
            </tr>
          </thead>
          <tbody>
            {filteredProducts.length === 0 ? (
              <tr>
                <td colSpan={7} className={`px-6 py-8 text-center ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
                  {t("noProducts")}
                </td>
              </tr>
            ) : (
              filteredProducts.map((product) => (
                <tr
                  key={product.id}
                  className={`border-b transition-colors ${
                    isDarkMode ? "border-gray-700 hover:bg-gray-700" : "border-gray-200 hover:bg-gray-50"
                  }`}
                >
                  <td className={`px-6 py-4 text-sm font-medium ${isDarkMode ? "text-white" : "text-gray-900"}`}>
                    {product.name}
                  </td>
                  <td className={`px-6 py-4 text-sm ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                    {product.sku}
                  </td>
                  <td className={`px-6 py-4 text-sm font-semibold ${isDarkMode ? "text-white" : "text-gray-900"}`}>
                    {product.price}
                  </td>
                  <td className={`px-6 py-4 text-sm ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                    {product.stock}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                      {product.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        product.status === "Active" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                      }`}
                    >
                      {product.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => onEditProduct?.(product.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          isDarkMode
                            ? "hover:bg-gray-600 text-gray-400 hover:text-white"
                            : "hover:bg-gray-200 text-gray-600 hover:text-gray-900"
                        }`}
                      >
                        <Edit2 size={16} />
                      </button>
                      <button
                        onClick={() => onDeleteProduct?.(product.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          isDarkMode
                            ? "hover:bg-red-900 text-gray-400 hover:text-red-400"
                            : "hover:bg-red-100 text-gray-600 hover:text-red-600"
                        }`}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
