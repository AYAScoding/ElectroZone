"use client"

import { useState, createContext, useContext } from "react"
import Sidebar from "./sidebar"
import Header from "./admin-header"
import Overview from "./sections/overview"
import ProductManagement from "./sections/product-management"
import Collections from "./sections/collections"
import Orders from "./sections/orders"
import Settings from "./sections/settings"
import { translations, type Language } from "@/lib/translations"

type TabType = "overview" | "products" | "collections" | "orders" | "settings"

interface ThemeContextType {
  isDarkMode: boolean
  toggleDarkMode: () => void
  accentColor: string
  setAccentColor: (color: string) => void
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: keyof typeof translations.en) => string
}

const ThemeContext = createContext<ThemeContextType>({
  isDarkMode: false,
  toggleDarkMode: () => {},
  accentColor: "green",
  setAccentColor: () => {},
  language: "en",
  setLanguage: () => {},
  t: (key) => key,
})

export const useTheme = () => useContext(ThemeContext)

interface AdminDashboardProps {
  overviewData?: {
    stats?: {
      totalItems?: { value: string; change: string }
      totalOrders?: { value: string; change: string }
      outOfStock?: { value: string; change: string }
      revenue?: { value: string; change: string }
    }
    recentActivities?: Array<{
      id: number
      action: string
      description: string
      time: string
    }>
    topProducts?: Array<{
      id: number
      name: string
      sales: number
    }>
  }
  productsData?: Array<{
    id: number
    name: string
    sku: string
    price: string
    stock: number
    category: string
    status: string
  }>
  collectionsData?: Array<{
    id: number
    name: string
    items: number
    featured: boolean
  }>
  ordersData?: Array<{
    id: string
    customer: string
    amount: string
    status: string
    date: string
  }>
  onAddProduct?: (product: any) => void
  onEditProduct?: (id: number) => void
  onDeleteProduct?: (id: number) => void
  onAddCollection?: () => void
  onEditCollection?: (id: number) => void
  onDeleteCollection?: (id: number) => void
  onViewOrder?: (id: string) => void
}

export default function AdminDashboard({
  overviewData,
  productsData,
  collectionsData,
  ordersData,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  onAddCollection,
  onEditCollection,
  onDeleteCollection,
  onViewOrder,
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<TabType>("overview")
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [accentColor, setAccentColor] = useState("green")
  const [language, setLanguage] = useState<Language>("en")

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
  }

  const t = (key: keyof typeof translations.en): string => {
    return translations[language][key] || key
  }

  const renderContent = () => {
    switch (activeTab) {
      case "overview":
        return (
          <Overview
            stats={overviewData?.stats}
            recentActivities={overviewData?.recentActivities}
            topProducts={overviewData?.topProducts}
          />
        )
      case "products":
        return (
          <ProductManagement
            products={productsData}
            onAddProduct={onAddProduct}
            onEditProduct={onEditProduct}
            onDeleteProduct={onDeleteProduct}
          />
        )
      case "collections":
        return (
          <Collections
            collections={collectionsData}
            onAddCollection={onAddCollection}
            onEditCollection={onEditCollection}
            onDeleteCollection={onDeleteCollection}
          />
        )
      case "orders":
        return <Orders orders={ordersData} onViewOrder={onViewOrder} />
      case "settings":
        return <Settings />
      default:
        return (
          <Overview
            stats={overviewData?.stats}
            recentActivities={overviewData?.recentActivities}
            topProducts={overviewData?.topProducts}
          />
        )
    }
  }

  return (
    <ThemeContext.Provider
      value={{ isDarkMode, toggleDarkMode, accentColor, setAccentColor, language, setLanguage, t }}
    >
      <div className={`flex h-screen ${isDarkMode ? "bg-gray-900" : "bg-gray-50"}`}>
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} isOpen={sidebarOpen} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header setSidebarOpen={setSidebarOpen} sidebarOpen={sidebarOpen} />
          <main className="flex-1 overflow-auto">
            <div className="p-6 md:p-8">{renderContent()}</div>
          </main>
        </div>
      </div>
    </ThemeContext.Provider>
  )
}
