"use client"

import { useState, useEffect } from "react"
import AdminDashboard from "@/components/admin-dashboard"

export default function Home() {
  // Example state to hold backend data
  const [dashboardData, setDashboardData] = useState({
    overview: undefined,
    products: undefined,
    collections: undefined,
    orders: undefined,
    analytics: undefined,
  })

  // Example: Fetch data from your backend API
  useEffect(() => {
    // Replace these URLs with your actual backend endpoints
    const fetchData = async () => {
      try {
        // Example API calls - replace with your actual endpoints
        // const overviewResponse = await fetch('/api/dashboard/overview')
        // const overviewData = await overviewResponse.json()
        // setDashboardData(prev => ({ ...prev, overview: overviewData }))
        // const productsResponse = await fetch('/api/products')
        // const productsData = await productsResponse.json()
        // setDashboardData(prev => ({ ...prev, products: productsData }))
        // Add more API calls for other sections...
      } catch (error) {
        console.error("Error fetching dashboard data:", error)
      }
    }

    // Uncomment to enable data fetching
    // fetchData()
  }, [])

  // Example handlers for CRUD operations - connect to your backend
  const handleAddProduct = async (productData: any) => {
    console.log("[v0] Add product:", productData)
    // Example: await fetch('/api/products', { method: 'POST', body: JSON.stringify(productData) })
  }

  const handleEditProduct = async (id: number) => {
    console.log("[v0] Edit product:", id)
    // Example: await fetch(`/api/products/${id}`, { method: 'PUT', body: JSON.stringify(data) })
  }

  const handleDeleteProduct = async (id: number) => {
    console.log("[v0] Delete product:", id)
    // Example: await fetch(`/api/products/${id}`, { method: 'DELETE' })
  }

  const handleAddCollection = async () => {
    console.log("[v0] Add collection")
    // Example: await fetch('/api/collections', { method: 'POST' })
  }

  const handleEditCollection = async (id: number) => {
    console.log("[v0] Edit collection:", id)
    // Example: await fetch(`/api/collections/${id}`, { method: 'PUT' })
  }

  const handleDeleteCollection = async (id: number) => {
    console.log("[v0] Delete collection:", id)
    // Example: await fetch(`/api/collections/${id}`, { method: 'DELETE' })
  }

  const handleViewOrder = async (id: string) => {
    console.log("[v0] View order:", id)
    // Example: Navigate to order detail page or open modal
  }

  return (
    <AdminDashboard
      overviewData={dashboardData.overview}
      productsData={dashboardData.products}
      collectionsData={dashboardData.collections}
      ordersData={dashboardData.orders}
      analyticsData={dashboardData.analytics}
      onAddProduct={handleAddProduct}
      onEditProduct={handleEditProduct}
      onDeleteProduct={handleDeleteProduct}
      onAddCollection={handleAddCollection}
      onEditCollection={handleEditCollection}
      onDeleteCollection={handleDeleteCollection}
      onViewOrder={handleViewOrder}
    />
  )
}
