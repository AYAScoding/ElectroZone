"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import type { CartItem, Product } from "@/lib/types"

interface CartContextType {
  items: CartItem[]
  addToCart: (product: Product, quantity?: number) => void
  removeFromCart: (productId: string) => void
  updateQuantity: (productId: string, quantity: number) => void
  clearCart: () => void
  total: number
  itemCount: number
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])

  const addToCart = (product: Product, quantity = 1) => {
    setItems((currentItems) => {
      const existingItem = currentItems.find((item) => item.product.id === product.id)

      if (existingItem) {
        return currentItems.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item,
        )
      }

      return [...currentItems, { product, quantity }]
    })

    // TODO: Sync with backend
    // await fetch('/api/cart/add', {
    //   method: 'POST',
    //   body: JSON.stringify({ productId: product.id, quantity })
    // })
  }

  const removeFromCart = (productId: string) => {
    setItems((currentItems) => currentItems.filter((item) => item.product.id !== productId))

    // TODO: Sync with backend
    // await fetch('/api/cart/remove', {
    //   method: 'POST',
    //   body: JSON.stringify({ productId })
    // })
  }

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId)
      return
    }

    setItems((currentItems) =>
      currentItems.map((item) => (item.product.id === productId ? { ...item, quantity } : item)),
    )

    // TODO: Sync with backend
    // await fetch('/api/cart/update', {
    //   method: 'POST',
    //   body: JSON.stringify({ productId, quantity })
    // })
  }

  const clearCart = () => {
    setItems([])
    // TODO: Sync with backend
    // await fetch('/api/cart/clear', { method: 'POST' })
  }

  const total = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <CartContext.Provider value={{ items, addToCart, removeFromCart, updateQuantity, clearCart, total, itemCount }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext) // Fix the import or declare the variable before using it
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}
